export const up = async (next) => {
  // Handled by the connector manager
  next();
};

export const down = async (next) => {
  next();
};

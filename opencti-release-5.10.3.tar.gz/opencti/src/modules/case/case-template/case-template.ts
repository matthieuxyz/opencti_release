import { v4 as uuidv4 } from 'uuid';
import { type ModuleDefinition, registerDefinition } from '../../../schema/module';
import { ABSTRACT_INTERNAL_OBJECT } from '../../../schema/general';
import type { StixCaseTemplate, StoreEntityCaseTemplate } from './case-template-types';
import { ENTITY_TYPE_CASE_TEMPLATE, TEMPLATE_TASK_RELATION } from './case-template-types';
import caseTemplateTypeDefs from './case-template.graphql';
import convertCaseTemplateToStix from './case-template-converter';
import caseTemplateResolvers from './case-template-resolvers';
import { ENTITY_TYPE_TASK_TEMPLATE } from '../../task/task-template/task-template-types';
import type { RelationRefDefinition } from '../../../schema/relationRef-definition';

const CaseTemplateToTaskTemplateRelation: RelationRefDefinition = {
  inputName: 'tasks',
  databaseName: TEMPLATE_TASK_RELATION,
  stixName: 'task_refs',
  mandatoryType: 'internal',
  multiple: true,
  checker: (_, toType) => toType === ENTITY_TYPE_TASK_TEMPLATE,
  datable: false,
};

const CASE_TEMPLATE_DEFINITION: ModuleDefinition<StoreEntityCaseTemplate, StixCaseTemplate> = {
  type: {
    id: 'case-template',
    name: ENTITY_TYPE_CASE_TEMPLATE,
    category: ABSTRACT_INTERNAL_OBJECT
  },
  graphql: {
    schema: caseTemplateTypeDefs,
    resolver: caseTemplateResolvers,
  },
  identifier: {
    definition: {
      [ENTITY_TYPE_CASE_TEMPLATE]: () => uuidv4(),
    },
  },
  attributes: [
    { name: 'name', type: 'string', mandatoryType: 'external', multiple: false, upsert: true },
    { name: 'description', type: 'string', mandatoryType: 'no', multiple: false, upsert: true },
  ],
  relations: [],
  relationsRefs: [CaseTemplateToTaskTemplateRelation],
  representative: (stix: StixCaseTemplate) => {
    return stix.name;
  },
  converter: convertCaseTemplateToStix
};
registerDefinition(CASE_TEMPLATE_DEFINITION);

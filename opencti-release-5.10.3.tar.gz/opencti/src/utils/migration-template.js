export const up = async (next) => {
  next();
};

export const down = async (next) => {
  next();
};

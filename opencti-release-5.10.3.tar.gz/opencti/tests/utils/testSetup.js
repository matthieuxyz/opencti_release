import cacheManager from '../../src/manager/cacheManager';

cacheManager.init();
